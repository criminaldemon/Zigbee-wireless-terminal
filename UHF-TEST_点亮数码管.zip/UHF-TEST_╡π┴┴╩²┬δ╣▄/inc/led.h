#ifndef _LED_H_
#define _LED_H_

#include <ioCC1110.h>
#include <oneway.h>
#include <hal.h>

//������ƵƵĶ˿�
// LED, Pushbutton Assignments

#define LED_BLUE_REG      P1
#define LED_BLUE          P1_7  //0x80
#define LED_GREEN_REG     P1
#define LED_GREEN         P1_1  //0x02
#define LED_YELLOW_REG    P1
#define LED_YELLOW        P1_2  //0x04
#define LED_RED_REG       P1
#define LED_RED           P1_3  //0x08

void Led_Initial(void);

#endif