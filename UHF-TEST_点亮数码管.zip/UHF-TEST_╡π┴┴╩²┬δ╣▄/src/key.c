#include <key.h>

//注意：该宏定义，定义在keyscan.h文件中
//#define KEYDEBOUNCE 0x05             //消抖动，按键扫描次数。如果连续5次都是扫描的都是相同键值，则认为是有效键值，否则是误触发

unsigned int g_uiCurrKey;            //当前按键值
//unsigned int g_uiLastKey;            //上次按键值
unsigned int g_uiKeyScanCount;       //按键扫描计数，作用：消抖动

unsigned int g_uiPreKeyValue;        // 上一次的有效按键值

unsigned int g_uiKeyDown;            //键被按下，返回的键值。       作用：单次按键，单次返回有效键值；按住不放，也只返回被按下的一个键值
unsigned int g_uiKeyRelease;         //键被释放后，返回的键值。     作用：只有按下的按键被释放后，才返回按下的键值
unsigned int g_uiKeyContinue;        //键连续按键，重复返回的键值。 作用：只要按住不放，就会重复地返回相同键值

UINT16 key_cnt = 0;
UINT16 KeyContinue_cnt = 0;
UINT16 KeyTIMEOUT_cnt = 0;
BOOL KeyContinue_event = 0;
UINT8 SystemMenuState = 0;
BOOL MIC_LOCK = FALSE;

extern BOOL startAutoCH;

//P1口的低八位作为按键
//没有按键时，返回的是0xff，
void Int_Key_Scan(void)
{
    static unsigned short LastReadKey = 0xFF;        //上次从IO口读取的键值 ,注意是静态变量
    //volatile unsigned short CurrReadKey;               //当前从IO口读取的键值
    volatile unsigned short CurrReadKey;
    //当前从IO口读取的键值
/*    
    CurrReadKey = (RegBuf[0]|0xFA)&(RegBuf[1]|0xEF);                //获取当前的键值
    //CurrReadKey =((P2_4<<4)|(P1_2<<2)|(P1_0));
*/
    CurrReadKey = KEY_REG;

    if(CurrReadKey == LastReadKey)            //如果当前读取的键值与上次从IO口读取的键值相同
    {
        if(g_uiKeyScanCount >= KEYDEBOUNCE)   //首先判断是否大于等于debounce的设定值(即是，是否大于等于设定的采样次数)
        {
            //按住不放,多次响应
            g_uiCurrKey = CurrReadKey;                //如果是,将当前的读取值判定为有效按键值(如果是，在采样周期中，都是这个值，则判定为有效按键值)
            g_uiKeyContinue = g_uiCurrKey ;           //长按，多次响应 按键值

            //按住不放只响应一次
            if(g_uiPreKeyValue == g_uiCurrKey)
            {
                g_uiKeyDown = 0xff;                    //没有键值
            }
            else
            {
                g_uiKeyDown = g_uiCurrKey;             //如果不同，按键有效,(就是第一次有效值时)
            }

            //按键释放时，按键值才有效     
            if(g_uiCurrKey == 0xff)                  //当有效按键值从非0到0的状态时(即是，从有按键到无按键，表示已经释放了)，表示之前按键已经释放了
            {
                g_uiKeyRelease = g_uiPreKeyValue;
            }

            g_uiPreKeyValue = g_uiCurrKey;               //记录上次有效按键值
        }
        else                                       //如果否，则debounce加一(如果否，则继续采样键值)
        {
            g_uiKeyScanCount++;
        }
    }
    else                                          //如果当前读取的键值与上次从IO口读取的键值不同，说明按键已经变化
    {
        g_uiKeyDown = 0xff;                       //放开按键后第一次进入扫描程序，清零g_uiKeyDown.
        g_uiKeyRelease = 0xff;
        g_uiKeyScanCount = 0;                     //清零之前的按键的debounce计数
        LastReadKey = CurrReadKey;                //将当前读取的键值记录为上次读取的按键值

        KeyContinue_cnt = 0;                      //清除连续长按键计数 

    }   
}

void RXMenu_KeyScan(void){
          
//第二种：KeyRelease的使用
//只有当按键释放之后，才返回一次有效键值，即是按键释放后，才执行相应的函数
  switch(g_uiKeyRelease){
        
            case KEY_1:
              //KEY_1按键程序   
              KeyTIMEOUT_cnt = 0;              
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              DisplayState = Vol_State; 
              if((SPK_Vol_State+VOLUME_STEP)<VOLUME_MAX+1){
                if(!Codec_SPK_VolCtrl(SPK_Vol_State+VOLUME_STEP))
                  P1_3=0; 
                               
              }
              break; 

            case KEY_2:
              //KEY_2按键程序 
              KeyTIMEOUT_cnt = 0;
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              DisplayState = Vol_State;           
              if((SPK_Vol_State-VOLUME_STEP)>VOLUME_MIN-1){
                if(!Codec_SPK_VolCtrl(SPK_Vol_State-VOLUME_STEP))
                  P1_3=0; 
  
              }
              break; 

            case KEY_3:
              //KEY_3按键程序
              KeyTIMEOUT_cnt = 0;              
              if(KeyContinue_event){

                KeyContinue_event=0;
                break;
              }
              
              if(SPKMute_State == Mute_OFF){
                if(!Codec_SPK_MuteCtrl(Mute_ON))
                  P1_3=0; 
                }

              else{
                if(!Codec_SPK_MuteCtrl(Mute_OFF))
                  P1_3=0; 
              }
              DisplayState = Vol_State; 
              
              break;
/*
            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
*/     

            case 0xFF:
              //没有按键程序
              if(DisplayState != RX_State){  
                if(KeyTIMEOUT_cnt<200)
                  KeyTIMEOUT_cnt++;
                
                else{
                DisplayState = RX_State;   
                WriteFlash = TRUE;
                KeyTIMEOUT_cnt = 0;  
                }
              }
              break;  

        }

 
//第三种：KeyContinue的使用
//1）单次按键（非长按），返回一次有效值。
//2）长按，返回多次相同有效值
  switch(g_uiKeyContinue){
        
            case KEY_1:
                         //KEY_1按键程序
                        if(KeyContinue_cnt<200)
                          KeyContinue_cnt++;
                        else{
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 1;
                          SystemMenuState = AutoCHTXMenu_State;
                          DisplayState = AutoCH_State;   
                          key_cnt=band;
                        }  
                        break;

            case KEY_2:
                        //KEY_2按键程序 
                        if(KeyContinue_cnt<200)
                          KeyContinue_cnt++;
                        else{                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 2;
                          SystemMenuState = ManualCHMenu_State;
                          DisplayState = ManualCH_State;  
                          key_cnt=band;  
                        }  
                        break;

            case KEY_3:
                        //KEY_3按键程序
                        if(KeyContinue_cnt<200)
                          KeyContinue_cnt++;
                        else{                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 3;
                          SystemMenuState = AutoCHRXMenu_State;
                          DisplayState = AutoCH_State; 
                          key_cnt=band;  
                        }  
                        break;

            case KEY_1&KEY_3:
                        //KEY_1&KEY_3按键程序
                        if(KeyContinue_cnt<200)
                          KeyContinue_cnt++;
                        else{                          
                          KeyContinue_cnt = 0;
                          SystemMenuState = TXMenu_State;
                          DisplayState = TX_State; 
                          //key_cnt=band;  
                          MIC_LOCK = TRUE;
                          
                        }
                        break;
/*
            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
*/     

            case 0xFF:
                        //没有按键程序
                        KeyContinue_cnt = 0;
                        KeyContinue_event = 0;
                        break;
                        
        }
}
  
  
void TXMenu_KeyScan(void){
//第二种：KeyRelease的使用
//只有当按键释放之后，才返回一次有效键值，即是按键释放后，才执行相应的函数
  switch(g_uiKeyRelease){
        
            case KEY_1:
              //KEY_1按键程序   
              KeyTIMEOUT_cnt = 0;
              DisplayState = Vol_State; 
              if((MIC_Vol_State+VOLUME_STEP)<VOLUME_MAX+1){
                if(!Codec_MIC_VolCtrl(MIC_Vol_State+VOLUME_STEP))
                  P1_3=0; 
              }
              break; 

            case KEY_2:
              //KEY_2按键程序 
              KeyTIMEOUT_cnt = 0;
              DisplayState = Vol_State;             
              if((MIC_Vol_State-VOLUME_STEP)>VOLUME_MIN-1){
                if(!Codec_MIC_VolCtrl(MIC_Vol_State-VOLUME_STEP))
                  P1_3=0; 
              }
              break; 

            case KEY_3:
              //KEY_3按键程序
              KeyTIMEOUT_cnt = 0;
              DisplayState = Vol_State;               
              if(MICMute_State == Mute_OFF){
                if(!Codec_MIC_MuteCtrl(Mute_ON))
                  P1_3=0; 
                }
              else{
                if(!Codec_MIC_MuteCtrl(Mute_OFF))
                  P1_3=0; 
              }
              
              break;
/*
            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
*/     

            case 0xFF:             
              //没有按键程序
              if(DisplayState != TX_State){  
                if(KeyTIMEOUT_cnt<200)
                  KeyTIMEOUT_cnt++;
                
                else{
                DisplayState = TX_State;   
                WriteFlash = TRUE;
                KeyTIMEOUT_cnt = 0;  
                }
              }
              break;  

        }
  //第三种：KeyContinue的使用
//1）单次按键（非长按），返回一次有效值。
//2）长按，返回多次相同有效值
  switch(g_uiKeyContinue){
    
            case KEY_1&KEY_3:
                        //KEY_1&KEY_3按键程序
                        if(KeyContinue_cnt<200)
                          KeyContinue_cnt++;
                        else{                          
                          KeyContinue_cnt = 0;
                          SystemMenuState = RXMenu_State;
                          DisplayState = RX_State; 
                          //key_cnt=band;  
                            MIC_LOCK = FALSE;
                        }
                        break;
/*
            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
*/     

            case 0xFF:
                        //没有按键程序
                        KeyContinue_cnt = 0;
                        KeyContinue_event = 0;
                        break;
                        
        }
  
}

void ManualCHMenu_KeyScan(void){
          
//第二种：KeyRelease的使用
//只有当按键释放之后，才返回一次有效键值，即是按键释放后，才执行相应的函数

  switch(g_uiKeyRelease){
        
            case KEY_1:
              //KEY_1按键程序
              KeyTIMEOUT_cnt = 0;  
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              
              key_cnt++;
              
              if(key_cnt>=TOTAL_NUM_BANDS)
                key_cnt=0;
              
              break;

            case KEY_2:
              //KEY_2按键程序 
              KeyTIMEOUT_cnt = 0;
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              
              if(key_cnt>0)
                key_cnt--;
              else
                key_cnt=TOTAL_NUM_BANDS-1;
              
              break; 
            case KEY_3:              
              //KEY_3按键程序
              KeyTIMEOUT_cnt = 0;
              KeyContinue_event=0;
              band = key_cnt;
              SystemMenuState = RXMenu_State; 
              DisplayState = RX_State;   
              break;
/*

            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
*/     

            case 0xFF:
              //没有按键程序
              if(KeyTIMEOUT_cnt<3000) //30s
                KeyTIMEOUT_cnt++;
              
              else{
              SystemMenuState = RXMenu_State; 
              DisplayState = RX_State;                 
              KeyTIMEOUT_cnt = 0;
              KeyContinue_event=0;
              }
              break;

        }

 
//第三种：KeyContinue的使用
//1）单次按键（非长按），返回一次有效值。
//2）长按，返回多次相同有效值
  switch(g_uiKeyContinue){
 /*       
            case KEY_1:
                         //KEY_1按键程序
              KeyTIMEOUT_cnt = 0;  
                        if(KeyContinue_cnt<100)
                          KeyContinue_cnt++;
                        else{
                          key_cnt += 10;
                          if(key_cnt>=TOTAL_NUM_BANDS)
                            key_cnt -= TOTAL_NUM_BANDS;
                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 1;
                        }  
                        break;

            case KEY_2:
                        //KEY_2按键程序 
              KeyTIMEOUT_cnt = 0;  
                        if(KeyContinue_cnt<100)
                          KeyContinue_cnt++;
                        else{                          
                          if(key_cnt<10)
                            key_cnt += TOTAL_NUM_BANDS;
                          key_cnt -= 10;
                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 2;
                        }  
                        break;

            case KEY_3:
                        //KEY_3按键程序
                        //LED_BLUE_REG ^= LED_BLUE;
                        key_cnt++;
                        if(key_cnt>99)
                          key_cnt=0;
                        break;

            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
*/     

            case 0xFF:
                        //没有按键程序

                        KeyContinue_cnt = 0;
                        KeyContinue_event = 0;
                        break;
                        
        }
}

void AutoCHTXMenu_KeyScan(void){
          
//第二种：KeyRelease的使用
//只有当按键释放之后，才返回一次有效键值，即是按键释放后，才执行相应的函数

  switch(g_uiKeyRelease){
        
            case KEY_1:
              //KEY_1按键程序
              KeyTIMEOUT_cnt = 0;  
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              
              key_cnt++;
              
              if(key_cnt>=TOTAL_NUM_BANDS)
                key_cnt=0;
              startAutoCH = FALSE ;
              break;

            case KEY_2:
              //KEY_2按键程序 
              KeyTIMEOUT_cnt = 0;
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              
              if(key_cnt>0)
                key_cnt--;
              else
                key_cnt=TOTAL_NUM_BANDS-1;
              startAutoCH = FALSE ;
              break; 
            case KEY_3:              
              //KEY_3按键程序
              KeyTIMEOUT_cnt = 0;
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              band = key_cnt;
              startAutoCH = TRUE ;
              
              break;
/*

            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
*/     

            case 0xFF:
              //没有按键程序
              if(KeyTIMEOUT_cnt<6000)
                KeyTIMEOUT_cnt++;
              
              else{
              SystemMenuState = RXMenu_State; 
              DisplayState = RX_State;   
              KeyTIMEOUT_cnt = 0;
              KeyContinue_event=0;
              startAutoCH = FALSE ;
              }

              break;

        }

 
//第三种：KeyContinue的使用
//1）单次按键（非长按），返回一次有效值。
//2）长按，返回多次相同有效值
  switch(g_uiKeyContinue){
/*        
            case KEY_1:
                         //KEY_1按键程序
              KeyTIMEOUT_cnt = 0;  
                        if(KeyContinue_cnt<100)
                          KeyContinue_cnt++;
                        else{
                          key_cnt += 10;
                          if(key_cnt>=TOTAL_NUM_BANDS)
                            key_cnt -= TOTAL_NUM_BANDS;
                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 1;
                        }
                        startAutoCH = FALSE ;
                        break;

            case KEY_2:
                        //KEY_2按键程序 
              KeyTIMEOUT_cnt = 0;  
                        if(KeyContinue_cnt<100)
                          KeyContinue_cnt++;
                        else{                          
                          if(key_cnt<10)
                            key_cnt += TOTAL_NUM_BANDS;
                          key_cnt -= 10;
                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 2;
                        }
                        startAutoCH = FALSE ;
                        break;
*/
            case KEY_3:
                        //KEY_3按键程序
                        if(KeyContinue_cnt<200)
                          KeyContinue_cnt++;
                        else{                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 3;
                          SystemMenuState = RXMenu_State;
                          DisplayState = RX_State;   
                          startAutoCH = FALSE ;
                          //band=key_cnt;  
                        }  
                        break;
/*
            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
*/     

            case 0xFF:
                        //没有按键程序

                        KeyContinue_cnt = 0;
                        KeyContinue_event = 0;
                        break;
                        
        }
} 
  

void AutoCHRXMenu_KeyScan(void){
          
//第二种：KeyRelease的使用
//只有当按键释放之后，才返回一次有效键值，即是按键释放后，才执行相应的函数

  switch(g_uiKeyRelease){
/*        
            case KEY_1:
              //KEY_1按键程序
              KeyTIMEOUT_cnt = 0;  
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              
              key_cnt++;
              
              if(key_cnt>=TOTAL_NUM_BANDS)
                key_cnt=0;
              startAutoCH = FALSE ;
              break;

            case KEY_2:
              //KEY_2按键程序 
              KeyTIMEOUT_cnt = 0;
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              
              if(key_cnt>0)
                key_cnt--;
              else
                key_cnt=TOTAL_NUM_BANDS-1;
              startAutoCH = FALSE ;
              break; 
            case KEY_3:              
              //KEY_3按键程序
              KeyTIMEOUT_cnt = 0;
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              band = key_cnt;
              startAutoCH = TRUE ;
              
              break;
*/
/*
            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
*/     

            case 0xFF:
              //没有按键程序
              if(KeyTIMEOUT_cnt<6000)
                KeyTIMEOUT_cnt++;
              
              else{
              SystemMenuState = RXMenu_State;  
              DisplayState = RX_State;                 
              KeyTIMEOUT_cnt = 0;
              KeyContinue_event=0;
              startAutoCH = FALSE ;
              }

              break;

        }

 
//第三种：KeyContinue的使用
//1）单次按键（非长按），返回一次有效值。
//2）长按，返回多次相同有效值
  switch(g_uiKeyContinue){
/*        
            case KEY_1:
                         //KEY_1按键程序
              KeyTIMEOUT_cnt = 0;  
                        if(KeyContinue_cnt<100)
                          KeyContinue_cnt++;
                        else{
                          key_cnt += 10;
                          if(key_cnt>=TOTAL_NUM_BANDS)
                            key_cnt -= TOTAL_NUM_BANDS;
                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 1;
                        }
                        startAutoCH = FALSE ;
                        break;

            case KEY_2:
                        //KEY_2按键程序 
              KeyTIMEOUT_cnt = 0;  
                        if(KeyContinue_cnt<100)
                          KeyContinue_cnt++;
                        else{                          
                          if(key_cnt<10)
                            key_cnt += TOTAL_NUM_BANDS;
                          key_cnt -= 10;
                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 2;
                        }
                        startAutoCH = FALSE ;
                        break;
*/
            case KEY_3:
                        //KEY_3按键程序
                        if(KeyContinue_cnt<200)
                          KeyContinue_cnt++;
                        else{                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 3;
                          SystemMenuState = RXMenu_State;
                          DisplayState = RX_State;   
                          startAutoCH = FALSE ;
                          //band=key_cnt;  
                        }  
                        break;
/*
            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
*/     

            case 0xFF:
                        //没有按键程序

                        KeyContinue_cnt = 0;
                        KeyContinue_event = 0;
                        break;
                        
        }
} 



/*
void Int_Key_Handle(void)
{
//第一种：KeyDown的使用
//单按时和长按时，都只返回一次有效键值（无需等到按键释放，就可以返回有效键值）
  switch(g_uiKeyDown){
  
            case KEY_1:
                         //KEY_1按键程序
                        //SendCmd(LCDON);	//开LCD显示
                        //LED_BLUE_REG ^= LED_BLUE;
                        key_cnt++;
                        if(key_cnt>999)
                          key_cnt=0;
                        break;    

            case KEY_2:
                        //KEY_2按键程序 
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case KEY_3:
                        //KEY_3按键程序 
                          key_cnt++;
                        if(key_cnt>999)
                          key_cnt=0;
                        break;

            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
     

            case 0xFF:
                        //没有按键程序
 //                       SendCmd(LCDON);	//打开LCD偏压发生器
                        //WriteAll_1621((6<<2),a,4);
                        break;  
                        
        }

          
//第二种：KeyRelease的使用
//只有当按键释放之后，才返回一次有效键值，即是按键释放后，才执行相应的函数
  switch(g_uiKeyRelease){
        
            case KEY_1:
              //KEY_1按键程序
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              
              key_cnt++;
              
              if(key_cnt>99)
                key_cnt=0;
              
              break;

            case KEY_2:
              //KEY_2按键程序 
              if(KeyContinue_event){
                KeyContinue_event=0;
                break;
              }
              
              if(key_cnt<1)
                key_cnt=99;
              else
                key_cnt--;
              
              break; 

            case KEY_3:
                        //KEY_3按键程序 
                          key_cnt++;
                        if(key_cnt>999)
                          key_cnt=0;
                        break;

            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
    

            case 0xFF:
                        //没有按键程序
 //                       SendCmd(LCDON);	//打开LCD偏压发生器
                        //WriteAll_1621((6<<2),a,4);
                        break;  

        }

 
//第三种：KeyContinue的使用
//1）单次按键（非长按），返回一次有效值。
//2）长按，返回多次相同有效值
  switch(g_uiKeyContinue){
        
            case KEY_1:
                         //KEY_1按键程序
                        if(KeyContinue_cnt<200)
                          KeyContinue_cnt++;
                        else{
                          key_cnt += 10;
                          if(key_cnt>99)
                            key_cnt -= 100;
                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 1;
                        }  
                        break;

            case KEY_2:
                        //KEY_2按键程序 
                        if(KeyContinue_cnt<200)
                          KeyContinue_cnt++;
                        else{                          
                          if(key_cnt<10)
                            key_cnt += 100;
                          key_cnt -= 10;
                          
                          KeyContinue_cnt = 0;
                          KeyContinue_event = 1;
                        }  
                        break;

            case KEY_3:
                        //KEY_3按键程序
                        //LED_BLUE_REG ^= LED_BLUE;
                        key_cnt++;
                        if(key_cnt>99)
                          key_cnt=0;
                        break;

            case 0xF7:
                        break;

            case 0xEF:
                        SendCmd(LCDOFF);	//关闭LCD显示
                        break;

            case 0xDF:
                        break;

            case 0xBF:
                        break;

            case 0xEF:
                        break; 
     

            case 0xFF:
                        //没有按键程序
                        KeyContinue_cnt = 0;
                        //WriteAll_1621((6<<2),a,4);
                        break;
                        
        }
}
*/