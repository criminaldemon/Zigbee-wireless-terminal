#include <key.h>

UINT8 COUNTER = 0;
UINT8 TEMP= 0;
uchar LCDbuffer[4];

UINT8 Set_Flag = 0;
UINT8 Select_Flag = 1;

void delay(u16 i)
{
while(i--); 
}

void key_read(void)
{
  static u16 key1_sum,key2_sum,key3_sum;
  if(KEY_1==0)    //��ⰴ��K2�Ƿ���
{ 
  key1_sum++;
  delay(1000);   //�������� һ���Լ10ms
  if(key1_sum == 1)  //�ٴ��жϰ����Ƿ���
  {    
   Set_Flag ^= 1;
   if(!Set_Flag)
   {
    /*LCDbuffer[0]=_spchar[0]; 
    LCDbuffer[1]=_number[(COUNTER/10)%10];
    LCDbuffer[2]=_number[COUNTER%10];
    LCDbuffer[3]=_rssi[2] | _battery[1];
    WriteAll_1621((6<<2),LCDbuffer,4);*/
   }
   else
   {
    /*LCDbuffer[0]=_spchar[10]; 
    LCDbuffer[1]=_number[0];
    LCDbuffer[2]=_number[TEMP%10];
    WriteAll_1621((6<<2),LCDbuffer,4);
   */
   }
  }
  while(!KEY_1);  //��ⰴ���Ƿ��ɿ�
 }  
 
//key2
if((KEY_2==0) && Set_Flag)   //��ⰴ��K2�Ƿ���
{ 
  key2_sum++;
  delay(1000);   //�������� һ���Լ10ms
  if(key2_sum == 1)  //�ٴ��жϰ����Ƿ���
  {    
    switch(Select_Flag)
    {
        case 1: COUNTER++;
                //if(COUNTER > 99) COUNTER = 0;
                LCDbuffer[0]=_spchar[0]; 
                LCDbuffer[1]=_number[(COUNTER/10)%10];
                LCDbuffer[2]=_number[COUNTER%10];
                LCDbuffer[3]=_rssi[2] | _battery[1];
                WriteAll_1621((6<<2),LCDbuffer,4);
                break;
        case 2: TEMP++; 
                //if(TEMP > 9) TEMP = 0;
                 LCDbuffer[0]=_spchar[10]; 
                 LCDbuffer[1]=_number[0];
                 LCDbuffer[2]=_number[TEMP%10];
                 WriteAll_1621((6<<2),LCDbuffer,4);
                break;
    }
  }
  while(!KEY_2);  //��ⰴ���Ƿ��ɿ�
 }  
 
//key3
if((KEY_3==0) && Set_Flag)   //��ⰴ��K2�Ƿ���
{ 
  key3_sum++;
  delay(1000);   //�������� һ���Լ10ms
  if(key3_sum == 1)  //�ٴ��жϰ����Ƿ���
  {    
    switch(Select_Flag)
    {
        case 1: COUNTER--;
               // if(COUNTER < 0) COUNTER = 0;
                LCDbuffer[0]=_spchar[0]; 
                LCDbuffer[1]=_number[(COUNTER/10)%10];
                LCDbuffer[2]=_number[COUNTER%10];
                LCDbuffer[3]=_rssi[2] | _battery[1];
                WriteAll_1621((6<<2),LCDbuffer,4);
                break;
        case 2: TEMP--; 
               // if(TEMP < 0) TEMP = 0;
                LCDbuffer[0]=_spchar[10]; 
                LCDbuffer[1]=_number[0];
                LCDbuffer[2]=_number[TEMP%10];
                WriteAll_1621((6<<2),LCDbuffer,4);
                break;
    }
  }
  while(!KEY_3);  //��ⰴ���Ƿ��ɿ�
 } 
}

