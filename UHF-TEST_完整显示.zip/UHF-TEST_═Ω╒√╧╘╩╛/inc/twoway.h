/*
 *******************************************************************************************************
 * Compiler:                IAR C Compiler for 8051                                                    *
 * Target platform:         Texas Instruments CC1110                                                   *
 * Author:                  TBR, KHO, ESY, MJB                                                         *
 *******************************************************************************************************
*/

#ifndef TWOWAY_H
#define TWOWAY_H

//-------------------------------------------------------------------------------------------------------
// Includes

#include "hal.h"
//#include "hal_CC2510.h"
#include "iocc1110.h"
#include "KeyScan.h"
#include "driver_iic.h"
#include "wm8974.h"
#include "adc.h"
#include "adpcm.h"   
#include "flash_dma.h"
#include "ht1621b.h"
//-------------------------------------------------------------------------------------------------------
// Compile-time options

// Choose MASTER mode by uncommenting the line below
//#define MASTER    // Use this if compiling code for the Master (beacon)
//#ifndef MASTER
//#define SLAVE         // Default to Slave if Master is not defined
//#endif

// data rate and modulation options
// Select (uncomment) only one!
//#define BAUD1_2kGFSK  
#define BAUD38_4kGFSK
//#define BAUD76_8kGFSK  
//#define BAUD100GFSK         // 100 kbps, GFSK modulation ��one way only,packet length = 54
//#define BAUD150GFSK         // 100 kbps, GFSK modulation ��one way only,packet length = 36
//#define BAUD200GFSK         // 200 kbps, GFSK modulation
//#define BAUD250GFSK         // 250 kbps, GFSK modulation

//#define PTK54
//#define PTK36
//#define PTK13
#define PTK300

// PA and LNA options
// Caution: only one option may be selected!

//#define CC1110_PA_Rev_C           // This version uses P2_4 for T/R
                                  // Setting P2_4 enables the PA  
//#define CC1110_LNA_Rev_B          // This version uses P2_4 for T/R
                                  // Setting bit P2_4 enables the LNA  
#define CC1110_EVM                // Standard CC1110 EVM (no PA or LNA)

//-------------------------------------------------------------------------------------------------------
// Global definitions

#define LISTEN_FOR_BASE_MODE    0x01
#define PAIRED_WITH_BASE_MODE   0x02

#define MAC_ADDR                    0xC3    // The system's 1 byte MAC address
#define RSSI_OFFSET                 77      // RSSI Offset (dB)
#define SYNCFND                     0x08    // SFD field of PKTSTATUS (Start of Frame Delimiter)

// Channel Table Length
#define CHANNEL_TABLE_LEN 4

// Number of ADC samples per packet

#ifdef PTK300
#define AF_LEN  300
#endif

#ifdef PTK54
#define AF_LEN  54
#endif

#ifdef PTK36
#define AF_LEN  36
#endif

#ifdef PTK18
#define AF_LEN  18
#endif

#ifdef PTK13
#define AF_LEN  13
#endif

// Audio frame and buffer size
#define AF_BUF_SIZE  AF_LEN+1    // Size of audio buffer = number of ADC samples

// Packet format and segment lengths (bytes)
#define PHY_FIELD_LEN               1       // Length byte
#define MAC_FIELD_LEN               1       // MAC address
#define STATUS_FIELD_LEN            1       // Status bits
#define MAC_APPENDED_STATUS_LEN     2       // Status bytes added by PHY (CC2510)

#ifdef MASTER
#define TX_PAYLOAD_LEN  (MAC_FIELD_LEN + STATUS_FIELD_LEN + 3 + (AF_LEN/2))
#define RX_PAYLOAD_LEN  (MAC_FIELD_LEN + STATUS_FIELD_LEN + 3 + (AF_LEN/2))
#else
#define RX_PAYLOAD_LEN  (MAC_FIELD_LEN + STATUS_FIELD_LEN + 3 + (AF_LEN/2))
#define TX_PAYLOAD_LEN  (MAC_FIELD_LEN + STATUS_FIELD_LEN + 3 + (AF_LEN/2))
#endif

// Define packet errors
#define PKT_ERROR_CNT_THR               10

// Frequency hopping
#define TOTAL_NUM_CHANNELS   4         // number of channels in the frequency hopping list
#define TOTAL_NUM_BANDS     5                     // number of Band in the frequency hopping list

// DMA Channels
#define DMA_RX  1
#define DMA_TX  2
#define DMA_AUDIO_IN  3
#define DMA_AUDIO_OUT 4

// Timer flags
#define T3OVFIF                         0x01

// RX Off modes
#define RXOFFMODE_IDLE                  0x00
#define RXOFFMODE_FSTXON                0x04
#define RXOFFMODE_TX                    0x08
#define RXOFFMODE_RX                    0x0C

// Marcstates
#define MARCSTATE_TX                    0x13
#define MARCSTATE_RX                    0x0D
#define MARCSTATE_IDLE                  0x01

// T2 (Frame timer) defines
// Note that T2 is a 'count down' timer; it starts at the vlaue set into T2CT and counts down to zero.
// T2 Tick period is 128 * T2PR clock cycles (128*6/26.0 = 29.538 usec)
// In Master mode, the frametimer is started (set to 'FRAME_TIMEOUT_DEFAULT') immediatly prior to sending a packet.
// In Slave mode, the frametimer is started (set to 'FRAME_TIMEOUT_DEFAULT') immediately after a packet is sucessfully received

// "FRAME_TIMEOUT_DEFAULT" is the time to collect ADC_SAMPLES samples at the ADC sample rate frequency, plus 250 usec
// "Frame_Time" = sample rate in msec * AF_LEN
//
// 8 kHz sample rate, 54 samples per packet: Frame_Time = .125 * 54 = 6.75 msec
// FRAME_TIMEOUT_DEFAULT = 6.75 + .250 = 7.000 msec 
// 8 kHz sample rate, 36 samples per packet: Frame_Time = .125 * 36 = 4.5 msec
// FRAME_TIMEOUT_DEFAULT = 4.5 + .250 = 4.75 msec 
// 8 kHz sample rate, 18 samples per packet: Frame_Time = .125 * 18 = 2.25 msec
// FRAME_TIMEOUT_DEFAULT = 2.25 + .250 = 2.5 msec 

// "LISTENFORMASTER" value calculation:
// Packet length (bytes) = AF_LEN + preamble bytes + sync bytes + CRC bytes + 3
// Packet length (usec) = packet length (bytes) * 8000 / data_rate in kbps
// Start Listening for Master packet length approximately packet length + 750 usec before the end of frame
//
// Example:
//
// data rate = 100 kbaud, sample rate = 8 kHz: 
// packet length (bytes) = 54 + 8 + 4 + 2 + 3 = 71 bytes
// packet length (usec) = 71 * 8000 / 100 = 5680 usec
// LISTENFORMASTER = 5680 + 750 = 6430 usec (or 6430 / 29.538 = 218 Timer2 tics)
//
// data rate = 150 kbaud, sample rate = 8 kHz: 
// packet length (bytes) = 36 + 8 + 4 + 2 + 3 = 53 bytes
// packet length (usec) = 53 * 8000 / 150 = 2827 usec
// LISTENFORMASTER = 2827 + 900 = 3727 usec (or 3727 / 29.538 = 126 Timer2 tics)
//
// data rate = 200 kbaud, sample rate = 8 kHz: 
// packet length (bytes) = 54 + 4 + 4 + 2 + 3 = 67 bytes
// packet length (usec) = 67 * 8000 / 200 = 2680 usec
// LISTENFORMASTER = 2680 + 750 = 3430 usec (or 3430 / 29.538 = 116 Timer2 tics)
//
// data rate = 200 kbaud, sample rate = 8 kHz,packet length = 18: 
// packet length (bytes) = 18 + 4 + 4 + 2 + 3 = 31 bytes
// packet length (usec) = 31 * 8000 / 200 = 1240 usec
// LISTENFORMASTER = 1240 + 750 = 1990 usec (or 1990 / 29.538 = 67 Timer2 tics)
//
// data rate = 250 kbbs, sample rate = 8 kHz: 
// packet length (bytes) = 54 + 4 + 4 + 2 + 3 = 67 bytes
// packet length (usec) = 67 * 8000 / 250 = 2144 usec
// LISTENFORMASTER = 2144 + 600 = 2744 usec (or 2744 / 29.538 = 93 Timer2 tics)

//packet length = 18
#ifdef PTK18

#define FRAME_TIMEOUT_DEFAULT            85       // (T2CT) Timeout = 85 * 29.538 us = 2.51073 msec
                                                  // Note that this is 250 usec longer than a frame, so T2 should never reach zero
#define END_OF_FRAME                      8       // T2CT count at end of frame (2.274 msec)
 
#ifdef BAUD200GFSK
//#define LISTENFORMASTER                 62       // Start listening for master 1830 usec before the T2 times out
#define LISTENFORMASTER                 59       // Start listening for master 1565.514 usec before the T2 times out
#endif //end of BAUD200GFSK

#endif //end of packet length = 18

//packet length = 36
#ifdef PTK36

#define FRAME_TIMEOUT_DEFAULT           161       // (T2CT) Timeout = 161 * 29.538 us = 4.756 msec
                                                  // Note that this is 250 usec longer than a frame, so T2 should never reach zero
#define END_OF_FRAME                      8       // T2CT count at end of frame (4.519   msec)
 
#ifdef BAUD150GFSK
#define LISTENFORMASTER                 126       // Start listening for master 3727 usec before the T2 times out
//#define LISTENFORMASTER                 130       // Start listening for master 3430 usec before the T2 times out
#define MASTER_RX_TIMEOUT                34       // Abort RX if GDO0 has not dropped 1004 usec before T2 times out
#endif //end of BAUD150GFSK

#endif //end of packet length = 36

//packet length = 54
#ifdef PTK54

#define FRAME_TIMEOUT_DEFAULT           237       // (T2CT) Timeout = 237 * 29.538 us = 7.000 msec
                                                  // Note that this is 250 usec longer than a frame, so T2 should never reach zero
#define END_OF_FRAME                      8       // T2CT count at end of frame (6.75 msec)
 
/*
#define FRAME_TIMEOUT_DEFAULT           245       // (T2CT) Timeout = 237 * 29.538 us = 7.250 msec
                                                  // Note that this is 500 usec longer than a frame, so T2 should never reach zero
#define END_OF_FRAME                     16       // T2CT count at end of frame (6.75 msec)
*/

#ifdef BAUD100GFSK
#define LISTENFORMASTER                 210       // Start listening for master   usec before the T2 times out
#define MASTER_RX_TIMEOUT                34       // Abort RX if GDO0 has not dropped 1004 usec before T2 times out
#endif

#ifdef BAUD200GFSK
#define LISTENFORMASTER                 116       // Start listening for master 3430 usec before the T2 times out
#define MASTER_RX_TIMEOUT                34       // Abort RX if GDO0 has not dropped 1004 usec before T2 times out
#endif

#ifdef BAUD250GFSK
#define LISTENFORMASTER                  93       // Start listening for master 2744 usec before the T2 times out
#define MASTER_RX_TIMEOUT                34       // Abort RX if GDO0 has not dropped 1004 usec before T2 times out
#endif

#endif //end of packet length = 54

// T3 Timeout defines (First parameter is timeout in 4.923076923 us, Second parameter is multiplier since this is a 8 bit timer only)
// For RX, the T3 timer sets the point (with reference to RX turn on) at which RX activity is checked. This is done by
// looking for high level on P1_5 (GDO0), which will be high from the time that SYNC is detected until the end of a packet.

// The value of "TX_TIMEOUT_WO_CALIB" is determined from packet length and data rate, as above
// Packet length (bytes) = AF_LEN + preamble bytes + sync bytes + CRC bytes + 3
// Packet length (usec) = packet length (bytes) * 8000 / data_rate in kbps
// Add approximately 250 usec to the value of 'packet length" 
//
// Example:
//
// data rate = 100 kbaud, sample rate = 8 kHz: 
// packet length (bytes) = 54 + 8 + 4 + 2 + 3 = 71 bytes
// packet length (usec) = 71 * 8000 / 100 = 5680 usec
// TX_TIMEOUT_WO_CALIB = 5680 + 250 = 5930 usec 
//
// data rate = 150 kbaud, sample rate = 8 kHz: 
// packet length (bytes) = 36 + 8 + 4 + 2 + 3 = 53 bytes
// packet length (usec) = 53 * 8000 / 150 = 2827 usec
// TX_TIMEOUT_WO_CALIB = 2827 + 250 = 3077 usec 
//
// data rate = 200 kbps, sample rate = 8 kHz: 
// packet length (bytes) = 67 + 4 + 4 + 2 + 3 = 67 bytes
// packet length (usec) = 67 * 8000 / 200 = 2680 usec
// TX_TIMEOUT_WO_CALIB = 2680 + 250 = 2930 usec 
//
// data rate = 200 kbaud, sample rate = 8 kHz,packet length = 18: 
// packet length (bytes) = 18 + 4 + 4 + 2 + 3 = 31 bytes
// packet length (usec) = 31 * 8000 / 200 = 1240 usec
// TX_TIMEOUT_WO_CALIB = 1240 + 250 = 1480 usec 
//
// data rate = 250 kbps, sample rate = 8 kHz: 
// packet length (bytes) = 67 + 4 + 4 + 2 + 3 = 67 bytes
// packet length (usec) = 67 * 8000 / 250 = 2144 usec
// TX_TIMEOUT_WO_CALIB = 2144 + 200 = 2344 usec 


#ifdef BAUD100GFSK
//#define MASTER_TX_TIMEOUT_WO_CALIB      200, 6    // Timeout = 200 * 4.923076923 us * 6 = 5907.6 us
#define MASTER_TX_TIMEOUT_WO_CALIB      195, 6    // Timeout = 195 * 4.923076923 us * 6 = 
//#define SLAVE_RX_SYNC_TIMEOUT           255, 1    // Timeout = 255 * 4.923076923 us * 1 = 1255.4 us
#define SLAVE_RX_SYNC_TIMEOUT           145, 2    // Timeout = 145 * 4.923076923 us * 2 = 1427.69230767 us
#endif

#ifdef BAUD150GFSK
#define MASTER_TX_TIMEOUT_WO_CALIB      125, 5    // Timeout = 125 * 4.923076923 us * 5 = 3076.9 us
//#define MASTER_TX_TIMEOUT_WO_CALIB      120, 5    // Timeout = 120 * 4.923076923 us * 5 = 2953.8461538 us
#define SLAVE_RX_SYNC_TIMEOUT           255, 1    // Timeout = 255 * 4.923076923 us * 1 = 1255.4 us
//#define SLAVE_RX_SYNC_TIMEOUT           132, 2    // Timeout = 145 * 4.923076923 us * 2 = 1299.692307672 us
//#define SLAVE_RX_SYNC_TIMEOUT           145, 2    // Timeout = 145 * 4.923076923 us * 2 = 1427.69230767 us
#endif

#ifdef PTK18

#ifdef BAUD200GFSK
//#define MASTER_TX_TIMEOUT_WO_CALIB      135, 2    // Timeout = 135 * 4.923076923 us * 2 = 1329.23076921 us
#define MASTER_TX_TIMEOUT_WO_CALIB      150, 2    // Timeout = 150 * 4.923076923 us * 2 = 1476.9230769 us
//#define SLAVE_RX_SYNC_TIMEOUT            140, 1    // Timeout = 140 * 4.923076923 us * 1 = 689.23076922 us
#define SLAVE_RX_SYNC_TIMEOUT            190, 1    // Timeout = 190 * 4.923076923 us * 1 = 935.38461537 us
#endif 

#else

#ifdef BAUD200GFSK
#define MASTER_TX_TIMEOUT_WO_CALIB      198, 3    // Timeout = 198 * 4.923076923 us * 3 = 2924.3 us
#define MASTER_RX_SYNC_TIMEOUT          255, 1    // Timeout = 255 * 4.923076923 us * 1 = 1255.4 us
#define SLAVE_TX_TIMEOUT_WO_CALIB       198, 3    // Timeout = 198 * 4.923076923 us * 3 = 2924.3 us
#define SLAVE_RX_SYNC_TIMEOUT           255, 1    // Timeout = 255 * 4.923076923 us * 1 = 1255.4 us
#endif 

#endif //END OF PTK18

#ifdef BAUD250GFSK
#define MASTER_TX_TIMEOUT_WO_CALIB      238, 2    // Timeout = 238 * 4.923076923 us * 2 = 2343.4 us
#define MASTER_RX_SYNC_TIMEOUT          255, 1    // Timeout = 255 * 4.923076923 us * 1 = 1255.4 us
#define SLAVE_TX_TIMEOUT_WO_CALIB       238, 2    // Timeout = 238 * 4.923076923 us * 2 = 2343.4 us
#define SLAVE_RX_SYNC_TIMEOUT           255, 1    // Timeout = 255 * 4.923076923 us * 1 = 1255.4 us
#endif

//#define LISTEN_FOR_BEACON_TIMEOUT       229, 24   // Timeout = 229 * 4.923076923 us * 24 = 27.057 msec
//#define LISTEN_FOR_BEACON_TIMEOUT       229, 17   // Timeout = 229 * 4.923076923 us * 17 = 19.165 msec
#define LISTEN_FOR_BEACON_TIMEOUT       250,  100   // Timeout = 250 * 4.923076923 us * 200 =  247 msec

// TX status flags
#define TX_IN_PROGRESS                  0x80
#define TX_SUCCESSFUL                   0x40
#define DEST_UNREACHABLE                0x20
#define TX_WAIT                         0x10
#define TX_IDLE                         0x00

// RX status flags
#define RX_IN_PROGRESS                  0x80
#define PACKET_RECEIVED                 0x40
#define RX_WAIT                         0x20
#define RX_COMPLETE                     0x10
#define RX_IDLE                         0x00

// RX packet/channel status
#define PKT_OK                          0x01
#define CRC_ERROR                       0x02
#define	TIMEOUT_ERROR                   0x04
#define PKT_ERROR                       0x08
#define DMA_ERROR                       0x10

//#define MISSING_MASK                   (CRC_ERROR | TIMEOUT_ERROR | PKT_ERROR | DMA_ERROR)
#define MISSING_MASK                    (TIMEOUT_ERROR | PKT_ERROR | DMA_ERROR | CRC_ERROR)
#define OK_MASK                         (PKT_OK)

// Packet status values/bits
#define CRC_OK_MASK     0x80
#define CRC_LQI_VAL_IDX 1
#define RSSI_VAL_IDX 0

// LED, Pushbutton Assignments

#define LED_BLUE_REG P1
#define LED_BLUE 0x80     // P1_7
#define LED_GREEN_REG P1
#define LED_GREEN  0x02   // P1_1
#define LED_YELLOW_REG P1
#define LED_YELLOW 0x04   // P1_2
#define LED_RED_REG P1
#define LED_RED 0x08      // P1_3

#define KEY_REG ((P1|0xFA)&(P2|0xEF))
#define KEY_1 0xEF            //P2_4
#define KEY_2 0xFE            //P1_0
#define KEY_3 0xFB            //P1_2

//----------------------------

typedef struct{ 
  WORD sample0;    //block�е�һ������ֵ��δѹ���� 
  BYTE index;     //��һ��block���һ��index����һ��block��index=0;
}BlockHeader;

#ifdef MASTER

// TX struct
typedef struct{
  BYTE macPayloadLen;                   // Length byte
  BYTE macField;                        // MAC address
  BYTE statusField;                     // Status Byte
  BlockHeader adpcmHeader;
  BYTE payload[AF_LEN/2];                 // Audio samples
} __xdata TX_MASTER_STRUCT;

// RX struct
typedef struct{
  BYTE macPayloadLen;                   // Length byte
  BYTE macField;                        // MAC address
  BYTE statusField;                     // Status byte
  BlockHeader adpcmHeader;
  BYTE payload[AF_LEN/2];                 // Audio samples
  BYTE append[MAC_APPENDED_STATUS_LEN]; // Status bytes (RSSI, LQI)
} __xdata RX_MASTER_STRUCT;

#endif

#ifdef SLAVE

// RX struct
typedef struct{
  BYTE macPayloadLen;                   // Length byte
  BYTE macField;                        // MAC address
  BYTE statusField;                     // Status Byte
  BlockHeader adpcmHeader;
  BYTE payload[AF_LEN/2];                 // Audio samples
  BYTE append[MAC_APPENDED_STATUS_LEN]; // Status bytes (RSSI, LQI)
} __xdata RX_SLAVE_STRUCT;

// TX struct
typedef struct{
  BYTE macPayloadLen;                   // Length byte
  BYTE macField;                        // MAC address
  BYTE statusField;                     // Status byte
  BlockHeader adpcmHeader;
  BYTE payload[AF_LEN/2];                 // Audio samples
} __xdata TX_SLAVE_STRUCT;

#endif

//-------------------------------------------------------------------------------------------------------
// Function prototype declarations
void _1621b(void);
void init_1621b(void);

// codec_TLV320AIC26.c
void initCodec(void);
void writeCodecRegister(BYTE pageaddress, BYTE address, INT16 data);

// tw_dma.c
void dmaAudio(void);
void dmaToRadio(WORD length, WORD srcAddr);
void dmaFromRadio(WORD length, WORD dstAddr);
void dmaMemtoMem(UINT16 length);

// tw_rf.c
BOOL initRf(void);
BOOL rfSendPacket(UINT8 timeout, UINT8 multiplier);
#ifdef MASTER
void rfReceivePacket(RX_MASTER_STRUCT __xdata * rxData, UINT8 synctimeout, UINT8 t3_multiplier, BYTE dmaNumber, UINT8 packetlen, UINT8 timeout);
#else
void rfReceivePacket(RX_SLAVE_STRUCT __xdata * rxData, UINT8 synctimeout, UINT8 t3_multiplier, BYTE dmaNumber, UINT8 packetlen, UINT8 timeout);
void ListenforMaster(RX_SLAVE_STRUCT __xdata * rxData, UINT8 timeout, UINT8 t3_multiplier, BYTE dmaNumber, UINT8 packetlen);
#endif

// tw_mac.c
void initFrameTimer(void);
void startFrameTimer(UINT8 cnt);
void macTimer3Init(void);
void macsetT3TimeoutAndWait(UINT8 timeout, UINT8 multiplier);
void setChannel (UINT8 ch);

//-------------------------------------------------------------------------------------------------------
// Global extern variables

#ifdef MASTER
extern TX_MASTER_STRUCT __xdata MAStxData[2];      // Data packet struct
extern RX_MASTER_STRUCT __xdata MASrxData[2];
extern INT16  __xdata audioBuffer[1][AF_BUF_SIZE];      // Audio In (microphone) Buffer
extern INT16  __xdata audioData[2][AF_BUF_SIZE];     // Audio Out (playback) Buffer
#endif

#ifdef SLAVE
extern RX_SLAVE_STRUCT __xdata SLVrxData[2];       // Data packet struct
extern TX_SLAVE_STRUCT __xdata SLVtxData[2];
extern INT16  __xdata audioData[2][AF_BUF_SIZE];      // Audio In (microphone) Buffer
extern INT16  __xdata audioBuffer[1][AF_BUF_SIZE];     // Audio Out (playback) Buffer
#endif

extern INT16 __xdata rssiavg;                   // allocated in tw_rf.c
extern UINT8 __xdata rssivalid;
extern BOOL   waitingforbeacon;

extern volatile BYTE __xdata txStatus;          // Status flags
extern volatile BYTE __xdata rxStatus;
extern volatile UINT8 __xdata rxPacketStatus;

extern UINT8 battery_level ;// ( 0 | 1 | 2 | 3 )
extern UINT8 rssi_level ;  // ( 0 | 1 | 2 | 3 )
extern BOOL MIC_KEY; //( 0 | 1 )


extern UINT8 __xdata activeTable[TOTAL_NUM_CHANNELS];
extern UINT8 __xdata syncTable[4];

//extern INT16  __xdata audioIn[2][AF_BUF_SIZE];      // Audio In (microphone) Buffer
extern UINT8 __xdata activeIn;                    // Audio Input active buffer (0 | 1)
//extern INT16  __xdata audioOut[2][AF_BUF_SIZE];     // Audio Out (playback) Buffer
extern UINT8 __xdata activeOut;                   // Audio Out active buffer (0 | 1)
//extern UINT8 __xdata SendPacket;                  // Bit will be set high when the buffer is available

// DMA
extern DMA_DESC __xdata DmaDesc1_4[];
extern DMA_DESC __xdata DmaDesc0;

extern UINT8 audioInindx;
extern UINT8 audioOutindx;
extern UINT16 timerSampleRate;
extern BOOL __xdata audioFrameReady;
extern BOOL __xdata rx1Ready;
extern BOOL __xdata rx2Ready;
extern UINT8 sampleCount;
extern UINT8 __xdata ActiveChIdx,band;
extern volatile BOOL sfdDetected;
extern BOOL dmaDone;
extern BOOL decodeDone;
extern UINT8 headerByte;
#endif

/***********************************************************************************
  Copyright 2009 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
***********************************************************************************/
