#include <led.h>

/**********************/
//��ʼ������
/**********************/
void Led_Initial(void)
{ 
  P1SEL = 0x02;
  P1DIR = 0xFA;
  LED_RED = 1;
  LED_BLUE = 1;
}