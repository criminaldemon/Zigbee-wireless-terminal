#include <key.h>

//#define KEYDEBOUNCE 0x05        //消抖动，按键扫描次数。如果连续5次都是扫描的都是相同键值，则认为是有效键值，否则是误触发

//对数据类型进行声明定义
UINT16 key_cnt = 0;
UINT16 KeyContinue_cnt = 0;
UINT16 KeyTIMEOUT_cnt = 0;
BOOL KeyContinue_event = 0;
UINT8 SystemMenuState = 0;
BOOL MIC_LOCK = FALSE;

UINT8 COUNTER = 0;
uchar LCDbuffer[4];


extern BOOL startAutoCH;

UINT8 __xdata ActiveChIdx,band;
//声明变量
unsigned int g_uiCurrKey;            //当前按键值
//unsigned int g_uiLastKey;            //上次按键值
unsigned int g_uiKeyScanCount;       //按键扫描计数，作用：消抖动
unsigned int g_uiPreKeyValue;        // 上一次的有效按键值

unsigned int g_uiKeyDown;            //键被按下，返回的键值。       作用：单次按键，单次返回有效键值；按住不放，也只返回被按下的一个键值
unsigned int g_uiKeyRelease;         //键被释放后，返回的键值。     作用：只有按下的按键被释放后，才返回按下的键值
unsigned int g_uiKeyContinue;        //键连续按键，重复返回的键值。 作用：只要按住不放，就会重复地返回相同键值

void delay(u16 i)
{
while(i--); 
}

void keypros()
{
  if(KEY_1==0)    //检测按键K2是否按下
{ 
  delay(1000);   //消除抖动 一般大约10ms
  if(KEY_1==0)  //再次判断按键是否按下
  {    
    COUNTER++;
    LED_RED = ~LED_RED;   //led状态取反
    LCDbuffer[0]=_spchar[10]; 
    LCDbuffer[1]=_number[(COUNTER/10)%10];
    LCDbuffer[2]=_number[COUNTER%10];
    WriteAll_1621((6<<2),LCDbuffer,4);
  }
  while(!KEY_1);  //检测按键是否松开
 }  

if(KEY_2==0)    //检测按键K2是否按下
{ 
  delay(1000);   //消除抖动 一般大约10ms
  if(KEY_2==0)  //再次判断按键是否按下
  {    
    COUNTER-- ;
    LED_BLUE = ~LED_BLUE;   //led状态取反
    LCDbuffer[0]=_spchar[10]; 
    LCDbuffer[1]=_number[(COUNTER/10)%10];
    LCDbuffer[2]=_number[COUNTER%10];
    WriteAll_1621((6<<2),LCDbuffer,4);
  }
  while(!KEY_2);  //检测按键是否松开
 }  
}

