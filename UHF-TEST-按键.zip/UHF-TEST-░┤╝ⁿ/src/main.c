#include <ioCC1110.h>
#include <key.h>
#include <led.h>
#include <hal.h>
#include <oneway.h>
#include <ht1621.h>

#define uint unsigned int
#define uchar unsigned char

//uint counter = 0;                  //ͳ���жϴ���
//uint TempFlag;                     //������־�Ƿ�Ҫ��˸

/****************************/
//����ʱ���ź���ӦƵ��
/****************************/
#define MHZ_26          0x00
#define HIGH_FREQUENCY_RC_OSC_STABLE    (SLEEP & 0x20)
#define CRYSTAL 0x00
#define XOSC_STABLE (SLEEP & 0x40)

#define SET_MAIN_CLOCK_SOURCE(source) \
do {                               \
     if(source) {                    \
        CLKCON |= 0x40;               \
          while(!HIGH_FREQUENCY_RC_OSC_STABLE); \
          SLEEP |= 0x04;                \
      }                               \
      else {                          \
        SLEEP &= ~0x04;               \
          while(!XOSC_STABLE);          \
          asm("NOP");                   \
          CLKCON &= ~0x47;              \
          SLEEP |= 0x04;                \
      }                               \
   }while (0)


#define SET_MAIN_CLOCK_SPEED(frequency)   \
do {                                   \
  CLKCON = ((CLKCON & ~0x07) | (frequency & 0x07));     \
}while (0)


/****************************/
//��������
/****************************/
void Delay(uint n);
void Initial(void);
 

/****************************/
//������
/****************************/
void main(void)
{
  
  Initial();
  Led_Initial();
  init_1621b();
  
  LED_RED = 1;
  LED_BLUE = 1;
  
  while(1)
  {
      
   //diaplay();
   keypros();
   //RXMenu_KeyScan();
     
   LED_BLUE = !LED_BLUE;
   Delay(10000);
   Delay(10000);
   Delay(10000);
   Delay(10000);
   Delay(10000);
   Delay(10000);
   
  }
}

/**********************/
//��ʱ
/**********************/
void Delay(uint n)
{
   uint tt;
   for(tt = 0;tt < n;tt ++);
   for(tt = 0;tt < n;tt ++);
   for(tt = 0;tt < n;tt ++);
   for(tt = 0;tt < n;tt ++);
   for(tt = 0;tt < n;tt ++);
}


void Initial(void)
{
  SLEEP &= ~0x04;
  SET_MAIN_CLOCK_SOURCE(CRYSTAL);
  SET_MAIN_CLOCK_SPEED(MHZ_26);  
  CLKCON = (CLKCON & 0xC7);
  P1SEL = 0x02;
  P1DIR = 0xFA;
  T1CTL = 0x3d;
  EA = 1;
  IEN1 = 0x02;
}

/************************
//�ж�
************************/
/*#pragma vector=TI_VECTOR
__interrupt void LED_IRQ(void)
{
  
     IRCON = 0x00;
     if(counter < 10)counter++;
     else
     {
       counter = 0;
     }
       if(TempFlag)      
            TempFlag = 0;
                  
         else
           
            TempFlag = 1;
       
}*/


























