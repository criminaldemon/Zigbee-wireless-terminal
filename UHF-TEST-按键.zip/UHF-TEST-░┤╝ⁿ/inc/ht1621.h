#ifndef _HT1621_H_
#define _HT1621_H_

#include <hal.h>
#include <ioCC1110.h>
#include <oneway.h>
#include <key.h>
#include <led.h>


#define BIAS 0x52
#define SYSEN 0x02
#define LCDON 0x06
#define LCDOFF 0x04

#define cs P1_4
#define wr P1_5
#define dat P1_6

#define uchar unsigned char

//���ֱ���
static UINT8 _number[10]={0xFA,0x60,0xBC,0xF4,0x66,0xD6,0xDE,0x70,0xFE,0xF6};
//RSSI����
static UINT8 _rssi[4]={0x80,0xC0,0xE0,0xF0};
//��ص�������
static UINT8 _battery[4]={0x01,0x05,0x0D,0x0F};

static UINT8 _spchar[11]={0x04,0x7A,0xEA,0xFA,0x1E,0x4C,0xCC,0x9A,0xEC,0x9E,0x7E};
// -,N,U,O,F��
// n,o,C,d,E,
// A,


//SYSTEM MENU SETTING 
#define RX_State                        0
#define Vol_State                       1
#define ManualCH_State                  2
#define AutoCH_State                    3
#define TX_State                        4

extern UINT8 DisplayState;

void SendBit_1621(uchar data,uchar cnt);
void SendDataBit_1621(uchar data,uchar cnt);
void SendCmd(uchar command);
void Write_1621(uchar addr,uchar data);
extern void WriteAll_1621(uchar addr,uchar *p,uchar cnt);
void init_1621b(void);
void diaplay(void);
void _1621b(void);
#endif


